package aloysius.lim.BakersDozen;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

import aloysius.lim.mycomponents.TitleLabel;

public class BakersDozen extends JFrame {
/**
 * Author: Aloysius Lim
 * Date Created: 8-30-18
 * Last Updated: 9-4-18
 */
	
	//Serialization of recreation
	private static final long serialVersionUID = 1L;

	//Create table panel
	private TablePanel tablePanel = new TablePanel();
	
	//Constructor
	public BakersDozen() {
		initGUI();
		setTitle("Baker's Dozen");
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	//Initialize GUI 
	private void initGUI() {
		TitleLabel gameTitle = new TitleLabel("Baker's Dozen");
		add(gameTitle,BorderLayout.PAGE_START);
		add(tablePanel,BorderLayout.CENTER);
		
		//Button panel
		JPanel btnPanel = new JPanel();
		btnPanel.setBackground(Color.black);
		add(btnPanel,BorderLayout.PAGE_END);
		
		//Start Btn
		JButton newBtn = new JButton("New Game");
		newBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				tablePanel.newGame();
			}
		});
		btnPanel.add(newBtn);
		
		JButton replayBtn = new JButton("Replay Game");
		replayBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				tablePanel.replay();
			}
		});
		btnPanel.add(replayBtn);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {			
			String className = UIManager.getSystemLookAndFeelClassName();
			UIManager.setLookAndFeel(className);
		}catch(Exception e){}
		
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				new BakersDozen();
			}
		});
	}
	
	
	
}
