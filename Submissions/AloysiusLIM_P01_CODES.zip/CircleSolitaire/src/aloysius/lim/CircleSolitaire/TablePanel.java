package aloysius.lim.CircleSolitaire;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;

public class TablePanel extends JPanel{
/**
 * Author: Aloysius Lim
 * Date Created: 9-9-18
 * Last Updated: 9-11-18
 */
	
	//Serialization
	private static final long serialVersionUID = 1L;
	
	/**** Constants ****/
	private static final int CARDWIDTH = Deck.getCardWidth();
	private static final int CARDHEIGHT = Deck.getCardHeight();
	
	private static final int SPACING = 25; //space between class
	private static final int MARGIN = 15; //margin around table
	
	//Actual Width & Height taking into account individual card width, spacing and margin 
	private static final int WIDTH = CARDWIDTH * 13 + MARGIN * 3; //Width of table
	private static final int HEIGHT = CARDHEIGHT * 9 + MARGIN * 3; //Height of table
	
	private static final int PILEX = WIDTH/2 - (4*CARDWIDTH + 3*SPACING)/7;
	private static final int PILEY = MARGIN * 6;
	private static final int OVERLAP = (int) (CARDHEIGHT * 0.65);
	
	//Declare the number of cards inside a pile
	private static final int CARDPERPILESTACK = 4;
	
	private Deck deck;
	private Card card;
	private CardStack[] pile = new CardStack[13];
	//Nested array to remember location of the pile cards
	private CardStack[][] pileStack = new CardStack[pile.length][CARDPERPILESTACK];

	//Constructor
	public TablePanel() {
		int x = PILEX;
		int y = PILEY;
		
		for (int i = 0;i<pile.length;i++) {
			//13th Pile, set up pile at middle
			if (i == 12) {
				x = PILEX;
				y = CARDHEIGHT * 4;
			}
			pile[i] = new CardStack(x,y,0);
			//Logic for creating a circle of pile cards
			if (i > 2) {
				if (i > 5) {
					y -= CARDHEIGHT + SPACING;
					if (i > 8) {
						x += (CARDWIDTH + SPACING * 2)*2;
					}
				}else {
					y += CARDHEIGHT + SPACING;
				}
				x -= CARDWIDTH + SPACING * 2;
			}else {
				y += CARDHEIGHT + SPACING;
				x += CARDWIDTH + SPACING * 2;				
			}
		}
		
		//assign the pileStacks into the different pile X,Y positions
		for (int r = 0;r<pile.length;r++) {			
			for (int i = 0;i<CARDPERPILESTACK;i++) {
				pileStack[r][i] = new CardStack(pile[r].getX(),pile[r].getY(),OVERLAP);
			}
		}
		
		//Deal the cards!
		deck = new Deck();
		deal();
	}
	
	public Dimension getPreferredSize() {
		Dimension size = new Dimension(WIDTH, HEIGHT);
		return size;
	}

	//Assign cards into each pile slots
	private void deal() {
		for(int row = 0; row<pile.length; row++){
			for (int col=0; col< 4; col++) {
				Card card = deck.deal();
				pileStack[row][col].add(card);
			}
		}
		repaint();
	}
	
	//Draw the background and cards into graphic
	public void paintComponent(Graphics g) {

		//draw background
		Graphics2D g2d = (Graphics2D) g;
		
		//Set optimization of rendering images, text, anti-aliasing and quality of render
	    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	    g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
	    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
	    
	    //color background
	    g2d.setColor(new Color(22,103,75));
		g2d.fillRect(0, 0, WIDTH, HEIGHT);
		
		//pile cards
		for (int i=0;i<pile.length;i++) {
			if (pile[i].size() > 0) {
				pile[i].draw(g2d);
			}else {
				int x = pile[i].getX();
				int y = pile[i].getY();
				Card.drawOutline(g2d, x, y);
			}
		}
		
		//draw board
		for (int r=0;r<pile.length;r++) {			
			for (int i=0;i<CARDPERPILESTACK;i++) {
				pileStack[r][i].draw(g2d);
			}
		}
	}
	
}
