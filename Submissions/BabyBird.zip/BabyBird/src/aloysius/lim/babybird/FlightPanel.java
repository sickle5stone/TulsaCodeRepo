package aloysius.lim.babybird;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

import aloysius.lim.mycommonmethods.FileIO;

/**
 * 
 * @author Aloysius Lim
 * Created: 16 Oct 2018
 * Modified: 23 Oct 2018
 */

public class FlightPanel extends JPanel {

	/**
	 * Serialization
	 */
	private static final long serialVersionUID = 1L;

	public static final int WIDTH = 600;
	public static final int HEIGHT = 600;
	private static final int SEPERATION = 40;
	private static final Font BIG_FONT = new Font(Font.DIALOG,Font.BOLD,30);
	private static final String THUD_SOUND = "thud.wav";
	
	/**** Variable ****/
	private BabyBird babyBird;
	private Bird bird = new Bird(HEIGHT);
	private Timer timer;
	private ArrayList<Wall> walls = new ArrayList<>();
	private int count = 0;
	private FontMetrics fm;
	
	public FlightPanel(BabyBird babyBird) {
		this.babyBird = babyBird;
		setFocusable(true);
		requestFocusInWindow(true);
		setFont(BIG_FONT);
		fm = getFontMetrics(BIG_FONT);
		
		//Listeners
		addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e){
				Character key = e.getKeyChar();
				if (key == ' ') {
					bird.startFlapping();
//					bird.move();
//					repaint();
				}
			}
		});
		
		Wall wall = new Wall(fm);
		walls.add(wall);
		
		//Timer flapping 
		timer = new Timer(40, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				timedAction();
			}
		});
		timer.start();
	}
	
	private void timedAction() {
		
		int changeY = bird.getChangeY();
		
		//moving the bird
		bird.move();
		
		int paintX = bird.getX();
		int paintY = bird.getY();
		
		if (changeY > 0) {
			paintY -= changeY;
		}
		int paintWidth = bird.getWidth();
		int paintHeight = bird.getHeight() + Math.abs(changeY);
		repaint(paintX,paintY,paintWidth,paintHeight);
		
		//moving walls
		for (int i = 0; i < walls.size(); i++) {
			Wall wall = walls.get(i);
			wall.move();
			if (wall.isPastWindowEdge()) {
				walls.remove(i);
				int points = wall.getPoints();
				babyBird.addToScore(points);
			}
			paintX = walls.get(i).getX();
			paintY = walls.get(i).getY();
			paintWidth = walls.get(i).getWidth() - walls.get(i).getChangeX();
			paintHeight = HEIGHT;
			repaint(paintX,paintY,paintWidth,paintHeight);
		}
		
		
		//checking collision
		Wall firstWall = walls.get(0);
		Rectangle birdBounds = bird.getBounds();
		Rectangle topWallBounds = firstWall.getTopBounds();
		Rectangle bottomWallBounds = firstWall.getBottomBounds();
		if (birdBounds.intersects(topWallBounds) || birdBounds.intersects(bottomWallBounds)) {
			nextLife();
		}
		
		//check for additional walls to be added
		count += 1;
		if (count>SEPERATION) {
			Wall wall = new Wall(fm);
			walls.add(wall);
			count = 0;
		}
		
	}
	
	private void nextLife() {
		FileIO.playClip(this, THUD_SOUND, false);
		babyBird.nextBird();
		count = 0;
		walls.clear();
		Wall wall = new Wall(fm);
		walls.add(wall);
		repaint();
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(WIDTH,HEIGHT);
	};
	
	public void paintComponent(Graphics g) {
		//Set background to blue
		g.setColor(Color.BLUE);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		//paint the bird
		bird.draw(g);
		
		//paint the walls
		for (int i = 0; i < walls.size(); i++) {
			walls.get(i).draw(g);
		}
	}
	
	public Bird getBird() {
		return bird;
	}
	
	public void restart() {
		count = 0;
		bird = new Bird(HEIGHT);
		walls.clear();
		Wall wall = new Wall(fm);
		walls.add(wall);
		repaint();
	}
}
