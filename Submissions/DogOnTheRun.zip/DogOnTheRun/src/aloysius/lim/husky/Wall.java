package aloysius.lim.husky;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

import aloysius.lim.mycommonmethods.FileIO;
import aloysius.lim.mycomponents.ScorePanel;

/**
 * 
 * @author Aloysius Lim
 * Created: 31 Oct 2018
 * Modified: 31 Oct 2018
 */

public class Wall {

	private static final String WALL_IMAGE_FILE = "snowbackground.jpg";
	private static final int CHANGE_X = -10;
	private static final int TOP_MIN = 100;
	private static final int TOP_MAX = 300;
	private static final int GAP_MIN = 100;
	private static final int GAP_MAX = 240;
	private static final int POINTS_OFFSET = 80;
	
	/**** Variables ****/
	private static BufferedImage wallImage;
	private static int width = 72;
	private static int height = 600;
	private int x = RunningPanel.WIDTH;
	private int bottomY;
	private int topHeight;
	private int bottomHeight;
	private int snowBottom;
	private BufferedImage topImage;
	private BufferedImage bottomImage;
	private Random rand = new Random();
	private int points = 1;
	private String pointsString;
	private int pointsX;
	
	
	public Wall(FontMetrics fm) {
		if (wallImage == null) {
			wallImage = FileIO.readImageFile(this, WALL_IMAGE_FILE);
			width = wallImage.getWidth();
			height = wallImage.getHeight();
		}
		
		snowBottom = RunningPanel.HEIGHT - height;
		
	}
	
	public void draw(Graphics g) {
		if (wallImage == null) {
			g.setColor(Color.CYAN);
			g.fillRect(x, 0, width, topHeight);
			g.fillRect(x, bottomY, width, bottomHeight);
		}else {
			g.setColor(Color.BLACK);
			g.drawImage(wallImage,0,snowBottom,null);
//			g.drawString(pointsString,x+pointsX,bottomY+POINTS_OFFSET);
		}
	}
	
	public void move() {
		x += CHANGE_X;
	}
	
	public boolean isPastWindowEdge() {
		int rightEdgeX = x + width;
		return (rightEdgeX < 0);
	}
		
	public int getPoints() {
		return points;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return 0;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getChangeX() {
		return CHANGE_X;
	}
	
}
