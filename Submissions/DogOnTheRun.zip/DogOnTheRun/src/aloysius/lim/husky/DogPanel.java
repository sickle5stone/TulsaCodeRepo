package aloysius.lim.husky;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

/**
 * 
 * @author Aloysius Lim
 * Created: 31 Oct 2018
 * Modified: 31 Oct 2018
 */

public class DogPanel extends JPanel {

	/**
	 * Serialization
	 */
	private static final long serialVersionUID = 1L;
	
	private static final int MARGIN = 10;
	private static final int SPACING = 20;
	
	/**** Variables ****/
	private BufferedImage image;
	private int count = 0;
	private int dogWidth;
	private int dogHeight;
	private int width;
	private int height;
	
	public DogPanel(BufferedImage image, int count) {
		this.image = image;
		this.count = count;
		dogWidth = image.getWidth();
		dogHeight = image.getHeight();
		width = dogWidth * count + MARGIN * 2 + (count-1) * SPACING;
		height = dogHeight + MARGIN * 2;
	}
	
	public void paintComponent(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, width, height);
		for (int i=0;i<count;i++) {
			int x = MARGIN + (dogWidth + SPACING) * i;
			g.drawImage(image, x, MARGIN, null);
		}
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(width,height);
	}
	
	public int removeDog() {
		count--;
		repaint();
		return count;
	}
	
	public void setDogCount(int count) {
		this.count = count;
		repaint();
	}
	

}
