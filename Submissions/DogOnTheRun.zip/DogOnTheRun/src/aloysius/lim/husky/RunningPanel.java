package aloysius.lim.husky;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import aloysius.lim.mycommonmethods.FileIO;

/**
 * 
 * @author Aloysius Lim
 * Created: 31 Oct 2018
 * Modified: 31 Oct 2018
 */

public class RunningPanel extends JPanel {

	/**
	 * Serialization
	 */
	private static final long serialVersionUID = 1L;

	public static final int WIDTH = 600;
	public static final int HEIGHT = 600;
	private static final int SEPERATION = 40;
	private static final Font BIG_FONT = new Font(Font.DIALOG,Font.BOLD,30);
	private static final String THUD_SOUND = "thud.wav";
	public static final int bottomWallHeight = 72;
	
	/**** Variable ****/
	private DogOnTheRun dogOnTheRun;
	private Husky husky = new Husky(HEIGHT-bottomWallHeight);
	private Timer timer;
	private ArrayList<Wall> walls = new ArrayList<>();
	private int count = 0;
	private FontMetrics fm;
	
	public RunningPanel(DogOnTheRun dogOnTheRun) {
		this.dogOnTheRun = dogOnTheRun;
		setFocusable(true);
		requestFocusInWindow(true);
		setFont(BIG_FONT);
		fm = getFontMetrics(BIG_FONT);
		
		//Listeners
		addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e){
				Character key = e.getKeyChar();
				if (key == ' ') {
					husky.startRunning();
				}
			}
		});
		
		Wall wall = new Wall(fm);
		walls.add(wall);
		
		//Timer flapping 
		timer = new Timer(40, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				timedAction();
			}
		});
		timer.start();
	}
	
	private void timedAction() {
		
		int changeY = husky.getChangeY();
		
		//moving the bird
		husky.move();
		
		int paintX = husky.getX();
		int paintY = husky.getY();
		
		if (changeY > 0) {
			paintY -= changeY;
		}
		int paintWidth = husky.getWidth();
		int paintHeight = husky.getHeight() + Math.abs(changeY);
		repaint(paintX,paintY,paintWidth,paintHeight);
		
		//moving walls
		for (int i = 0; i < walls.size(); i++) {
			Wall wall = walls.get(i);
			wall.move();
			if (wall.isPastWindowEdge()) {
				walls.remove(i);
				int points = wall.getPoints();
				dogOnTheRun.addToScore(points);
			}
			paintX = walls.get(i).getX();
			paintY = walls.get(i).getY();
			paintWidth = walls.get(i).getWidth() - walls.get(i).getChangeX();
			paintHeight = HEIGHT;
			repaint(paintX,paintY,paintWidth,paintHeight);
		}
		
		
		//checking collision
		
		
		//check for additional walls to be added
		count += 1;
		if (count>SEPERATION) {
			Wall wall = new Wall(fm);
			walls.add(wall);
			count = 0;
		}
		
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(WIDTH,HEIGHT);
	};
	
	protected void paintComponent(Graphics g) {
		//Set background to blue
//		g.setColor(Color.BLUE);
		BufferedImage back = FileIO.readImageFile(this, "lowerBack.jpg");
		super.paintComponent(g);
		g.drawImage(back,0,0,null);
//		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		//paint the husky
		husky.draw(g);
		
		//paint the walls
		for (int i = 0; i < walls.size(); i++) {
			walls.get(i).draw(g);
		}
	}
	
	public Husky getHusky() {
		return husky;
	}
	
	public void restart() {
		count = 0;
		husky = new Husky(HEIGHT);
		walls.clear();
		Wall wall = new Wall(fm);
		walls.add(wall);
		repaint();
	}
}
