package aloysius.lim.husky;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.logging.FileHandler;

import aloysius.lim.mycommonmethods.FileIO;

/**
 * 
 * @author Aloysius Lim
 * Created: 31 Oct 2018
 * Modified: 31 Oct 2018
 */

public class Husky {

	private static final String BIRD_RUN_UP = "babyBirdFlapUp.gif";
	private static final String BIRD_GLIDE = "babyBirdGlide.gif";
	private static final String BIRD_RUN_DOWN = "babyBirdFlapDown.gif";

	private static final String HUSKY_RUNNING = "huskysmall.gif";
	
	private final int RUN_UP = 0;
	private final int RUN_GLIDE = 1;
	private final int RUN_DOWN = 2;
	
	private static final float GRAVITY = .5f;
	private static final int RUN_FORCE = -8;
	
	/**** VARIABLE ****/
	
	private BufferedImage[] huskies = new BufferedImage[3];
	private int width;
	private int height;
	private int x = 10;
	private int y = 10;
	private int RUN = RUN_GLIDE;
	private boolean running = false;
	private float changeY = 0;
	private int panelHeight;
	private Image huskyGIF = FileIO.readGifFile(this, HUSKY_RUNNING);
	
	public Husky(int panelHeight) {
		huskies[RUN_UP] = FileIO.readImageFile(this, HUSKY_RUNNING);
		huskies[RUN_GLIDE] = FileIO.readImageFile(this, HUSKY_RUNNING);
		huskies[RUN_DOWN] = FileIO.readImageFile(this, HUSKY_RUNNING);
		width = huskies[0].getWidth();
		height = huskies[0].getHeight();
		this.panelHeight = panelHeight;
	}
	
	public void draw(Graphics g) {
		g.drawImage(huskyGIF, x, y, null);
	}

	public void startRunning() {
		running = true;
		changeY = RUN_FORCE;
	}
	
	public void move() {
		
		int changeYInt = Math.round(changeY);
		int distanceFromTop = y + height + changeYInt;
		if (distanceFromTop > panelHeight) {
			y = panelHeight - height;
			changeY = 0;
		}else {			
			y += changeYInt;
			changeY += GRAVITY;
			if (changeY > 0) {
				running = false;
			}
		}
		
		if (running) {
			RUN = (RUN+1)%3;
		}else {
			RUN = RUN_GLIDE;
		}
	}
	
	public Rectangle getBounds() {
		Rectangle bounds = new Rectangle(x,y,width,height);
		return bounds;
	}
	
	public BufferedImage getImage() {
		return huskies[RUN_GLIDE];
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public int getChangeY() {
		return (int) changeY;
	}
	
}
