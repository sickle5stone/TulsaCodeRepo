package aloysius.lim.husky;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import aloysius.lim.mycommonmethods.FileIO;
import aloysius.lim.mycomponents.ScorePanel;
import aloysius.lim.mycomponents.TitleLabel;

/**
 * 
 * @author Aloysius Lim
 * Created: 31 Oct 2018
 * Modified: 31 Oct 2018
 */

public class DogOnTheRun extends JFrame{

	private static final long serialVersionUID = 1L;
	
	private static final int LIVES = 4;
	
	private final Color SCORECOLOR = new Color(76,221,232);
	private ScorePanel scorePanel = new ScorePanel(0,SCORECOLOR);
	private RunningPanel runningPanel = new RunningPanel(this);
	private DogPanel dogPanel;

	public DogOnTheRun() {
		initGUI();
		
		setTitle("Baby Bird");
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	public static void main(String[] args) {
		try {
			String className = UIManager.getCrossPlatformLookAndFeelClassName();
			UIManager.setLookAndFeel(className);
		}catch(Exception e) {
			
		}
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
					new DogOnTheRun();
			}//end run
			// end runnable
		});
	} // end main
	
	public void initGUI() {
		//Title
		TitleLabel titleLabel = new TitleLabel("Baby Bird");
		add(titleLabel,BorderLayout.PAGE_START);
		
		//main panel
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.GREEN);
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		add(mainPanel, BorderLayout.CENTER);
		
		//score panel
		mainPanel.add(scorePanel);
		
		//running panel
		mainPanel.add(runningPanel);
		
		//bottom panel
		JPanel bottomPanel = new JPanel();
		bottomPanel.setBackground(Color.BLACK);
		add(bottomPanel,BorderLayout.PAGE_START);
		
		//bird nest panel
		Husky husky = runningPanel.getHusky();
		BufferedImage birdImage = husky.getImage();
		dogPanel = new DogPanel(birdImage,LIVES-1);
		System.out.println(birdImage);
		bottomPanel.add(dogPanel);
		
	} // end initGUI
	
	public void nextBird() {
		int birdsRemaining = dogPanel.removeDog();
		if (birdsRemaining < 0) {
			String message = "No more birds remain, do you want to play again?";
			int option = JOptionPane.showConfirmDialog(this, message, "Play again?", JOptionPane.YES_NO_OPTION);
			if (option == JOptionPane.YES_OPTION) {
				dogPanel.setDogCount(LIVES-1);
				scorePanel.reset();
				runningPanel.restart();
			}else {
				System.exit(0);
			}
		}
	}
	
	public void addToScore(int points) {
		scorePanel.addToScore(points);
	}
	
	
	
}
