package aloysius.lim.mytimer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import aloysius.lim.mycomponents.TitleLabel;

/**
 * Author: Aloysius Lim
 * Date Created: 10-02-18
 * Last Updated: 10-02-18
 */

public class myTimer extends JFrame{

	//verification for send/receive
	private static final long serialVersionUID = 1L;
	
	/**** VARIABLES ****/
	private Font font = new Font(Font.DIALOG, Font.BOLD, 36);
	private TimerPanel timerPanel = new TimerPanel(3,font);
	
	public myTimer() {
		initGUI();
	
		//JFrame settings
		setTitle("My Timer");
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	
	}
	
	public static void main(String[] args) {
		try {
			String className = UIManager.getCrossPlatformLookAndFeelClassName();
			UIManager.setLookAndFeel(className);
		}catch(Exception e) {}
	
		//Create new instance of MyTimer
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				new myTimer();
			}
		});
	
	}
	
	//Create GUI
	public void initGUI() {
		
		//New Title Label
		TitleLabel titleLabel = new TitleLabel("My Timer");
		add(titleLabel,BorderLayout.PAGE_START);
		
		//New JPanel
		JPanel centerPanel = new JPanel();
		centerPanel.setBackground(Color.GREEN);
		add(centerPanel,BorderLayout.CENTER);
		
		centerPanel.add(timerPanel);
		
		JPanel buttonPanel = new JPanel();
		add(buttonPanel,BorderLayout.PAGE_END);
		
		JButton hoursButton = new JButton();
		hoursButton.setText("Hour");
		hoursButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addAnHour();
			}
		});
		buttonPanel.add(hoursButton);
		
		JButton minutesButton = new JButton();
		minutesButton.setText("Min");
		minutesButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				addAnMinute();
			}
		});
		buttonPanel.add(minutesButton);
		
		JButton clearButton = new JButton();
		clearButton.setText("Clear");
		clearButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clear();
			}
		});
		buttonPanel.add(clearButton);
		
		JButton startButton = new JButton();
		startButton.setText("Start");
		startButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				start();
			}
		});
		buttonPanel.add(startButton);
		
		JButton stopButton = new JButton();
		stopButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				stop();
			}
		});
		stopButton.setText("Stop");
		buttonPanel.add(stopButton);
	}
	
	private void start() {
		timerPanel.start();
	}
	
	private void stop() {
		timerPanel.stop();
	}
	
	private void addAnHour() {
		long time = timerPanel.getTime();
		time += 3600;
		timerPanel.setTimer(time);
	}
	
	private void addAnMinute() {
		long time = timerPanel.getTime();
		time += 60;
		timerPanel.setTimer(time);
	}
	
	private void clear() {
		timerPanel.stop();
		timerPanel.setTimer(0);
	}
}
