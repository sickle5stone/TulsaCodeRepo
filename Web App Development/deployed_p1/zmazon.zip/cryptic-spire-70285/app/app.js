var config = {
    apiKey: "AIzaSyBthC9BLzwfHrmp1xiFk1rglVDqYQ5rB-s",
    authDomain: "cs-3033-fa18.firebaseapp.com",
    databaseURL: "https://cs-3033-fa18.firebaseio.com",
    projectId: "cs-3033-fa18",
    storageBucket: "cs-3033-fa18.appspot.com",
    messagingSenderId: "494659703474"
};

// initialize the firebase app
firebase.initializeApp(config);

var products = [];
var tempProd = [];
var count = 0;
var cardPerPage = 9;

function filterProducts(){
    var available       = ($("#available").is(":checked"));
    var unavailable     = ($("#unavailable").is(":checked"));
    var price0to25      = ($("#0to25").is(":checked"));
    var price25to50     = ($('#25to50').is(":checked"));
    var price50to100    = ($('#50to100').is(":checked"));
    var thumb1          = ($('#1thumb').is(":checked"));
    var thumb2          = ($('#2thumb').is(":checked"));

    //test values
    // console.log (
    //     [available,unavailable,price0to25,price25to50,price50to100,thumb1,thumb2]
    // )

    return products.filter(function(product) {
        //Setting up fail conditions
        if (available && !unavailable && product['stock'] <= 0){
            return false;
        }
        if (unavailable && !available && product['stock'] > 0){
            return false;
        }
        // if 0 to 25 checked
        if (price0to25 && !price25to50 && !price50to100 && (product["price"] < 0 || product["price"] > 25)){
            return false;
        }
        // if 0 to 25, 25 to 50 checked
        if (price25to50 && price0to25 && !price50to100 && (product["price"] < 0 || product["price"] > 50)){
            return false;
        }
        // if 0 to 25, 50 to 100 checked
        if (price0to25 && price50to100 && !price25to50 && ( (product["price"] < 50 && product["price"] > 25) || product["price"] < 0 || product["price"] > 100)){
            return false;
        }
        // if 25 to 50 checked
        if (price25to50 && !price0to25 && !price50to100 && (product["price"] < 25 || product["price"] > 50)){
            return false;
        }
        // if 25 to 50 checked, 50 to 100 checked
        if (price25to50 && price50to100 && !price0to25 && (product["price"] < 50 || product["price"] > 100)){
            return false;
        }
        // if 50 to 100 checked
        if (price50to100 && !price0to25 && !price25to50 && (product["price"] < 50 || product["price"] > 100)){
            return false;
        }
        if (thumb1 && !thumb2 && product["rating"] < 1 ){
            return false;
        }
        if (!thumb1 && thumb2 && product["rating"] < 2 ){
            return false;
        }
        if (thumb1 && thumb2 && product["rating"] < 1 ){
            return false;
        }
        // console.log(product)
        return true;
    })

}

function loadPagination(size){
    size = Math.ceil(size/cardPerPage)
    
    // console.log(size)
    $("#pagination").children().remove()
    if (size > 1){
        $('#pagination').append('<li class="page-item last-child"><a class="page-link" href="#">Next</a></li>')
        $("#pagination").children(":not(:last)").remove()
        $(".last-child").before('<li class="page-item"><a class="page-link" href="">Previous</a></li>')
    }
    for (var i = 0; i<size; i++){
        $(".last-child").before('<li class="page-item" id='+i+'><a class="page-link" onclick=changePage('+i+')>'+i+'</a></li>')
    }

}

function changePage(number,prod = tempProd){
    count = number
    // console.log("changed!")
    // console.log(count)
    $(".active").removeClass("active")
    $("#"+count).addClass("active")
    loadPage(prod)
}

function loadBook(){
    // save the firebase database to a variable named database
    var database = firebase.database();
    // use database to access "departments/books"
    database.ref("departments/books").once("value").then(function(snapshot) {
        // save the snapshot value to a local variable named data
        var data = snapshot.val();
        // log the data
        // console.log(data);
        // use JQuery to create a div "row" element
        // get all product names by using Object.keys, and iterate over with forEach
        Object.keys(data["products"]).forEach(function(key) {
            // save book to a local variable named book
            var book = data["products"][key];
            // row logic
            // log the book
            // console.log([book]);
            // push the book to products
            products.push(book);
            // use JQuery to create an h1 element with the text of the book's name
            // end forEach
        });
        // console.log(products)
        loadPage(products)
        var length = Object.keys(products).length;
        loadPagination(length)
        // use JQuery to append the "row" element to the "container" element
    });
    
    //end database
}

function progressbar(stock,limit){
    var decimal = stock / limit * 100;
    // console.log(decimal)
    progressbarnumbers = [0,25,50,75,100]
    var distance = 100;
    var index = 0;
    if (decimal === 0){
        return 0;
    }else if (decimal === 100){
        return 100;
    }else{
        progressbarnumbers.forEach(function(num,ind){
            if (decimal === num){
                // console.log("Did i run")
                return progressbarnumbers[ind]
            }else{
                var newDistance = Math.abs(num - decimal)
                // console.log(distance)
                if (newDistance < distance){
                    index = ind;
                    distance = newDistance
                }
            }
        })
        return progressbarnumbers[index]
    }
}

function countRating(rating){
    var starHTMLElement = "";
    for (var i=0;i<rating;i++){
        starHTMLElement+= "<i class='text-warning fa fa-star'></i>"
    }
    for (var i=2-rating;i>0;i--) {
        starHTMLElement+= "<i class='text-muted fa fa-star'></i>"
    } 
    return starHTMLElement;
}

function loadPage(products){
    var productList = $("#content-body")
    productList.empty();
    var row = $('<div class="row"></div>');

    products.slice(count*cardPerPage,count*cardPerPage+cardPerPage).forEach(function(book){            
        var bookHTML = $('<h5 class=\'card-title\'"></h5>').text(book["name"]);
        bookHTML.append($('<h6 class=\'text-muted\'></h6>').text("Category: "+book["genre"]));
        var bar = "w-"+progressbar(book["stock"],2)
        bookHTML.append($('<h6 class=\'card-text\'></h6>')
            .append('<div class="progress"><div style="background-color: rgba(255,255,0,0.25)" class="progress-bar '+bar+'"><span style="color:black; width: 80%; position:absolute; text-align: center"> Stock: '+book["stock"]+'</span></div></div>')
        );
        bookHTML.append($('<h6 class=\'card-text\'></h6>').text("Availability: "+ (book["stock"] === 0 ? "Not Available" : "Available")));
        bookHTML.append($('<h6 class=\'card-text\'></h6>').text("Price: $"+book["price"]));
        var rating = countRating(book["rating"])
        
        bookHTML.append($('<h6 class=\'card-text\'></h6>').append("Rating: "+rating));
        // bookHTML.append($('<h6 class=\'card-text\'></h6>').text("Rating: "+book["rating"]));

        // use JQuery to create a div "col" element
        var col = $('<div class="col-sm-4"></div>');
        var card = $('<div class="card mt-3 collapse" id="'+book["id"]+'"></div>');
        var cardBody = $('<div class="card-body"></div>');
        cardBody.append(bookHTML);
        card.append(cardBody);
        col.append(card);
        // append the book to the "col" element
        // append the "col" element to the "row" element
        row.append(col);
        productList.append(row);
    })
    // book
}

$(function() {

    $(".checkbox").click(function() {
        // var products = filterProducts();
        tempProd = filterProducts();
        var length = Object.keys(tempProd).length;
        // console.log(length)
        loadPagination(length)
        loadPage(tempProd)
        changePage(0)
    })
    loadBook()
    tempProd = products

});
