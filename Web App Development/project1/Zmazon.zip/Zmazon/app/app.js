var config = {
    apiKey: "AIzaSyBthC9BLzwfHrmp1xiFk1rglVDqYQ5rB-s",
    authDomain: "cs-3033-fa18.firebaseapp.com",
    databaseURL: "https://cs-3033-fa18.firebaseio.com",
    projectId: "cs-3033-fa18",
    storageBucket: "cs-3033-fa18.appspot.com",
    messagingSenderId: "494659703474"
};

// initialize the firebase app
firebase.initializeApp(config);

var products = [];

// function checkAvailable(id, productVar, checkCondition, checkLimit,inverse){
//     console.log("im here" + " #" + id + " " + productVar + " "+checkCondition)
//     $('#'+id).click(function() {
//         if ($(this).prop('checked')){
//             products.forEach(function(product){
//                 // console.log(product[`${productVar}`])
//                 var c = product[`${productVar}`]
//                 // console.log(c)
//                 var t = $(`#${product["id"]}`);
//                 t.hide()
//                 if (product[`${productVar}`] >= checkCondition && product[`${productVar}`] < checkLimit){
//                     // console.log("checked" + product["id"])
//                     t.addClass('collapse')
//                     // t.modal();
//                     t.show();
//                 }
//             })
//         }else{
//             products.forEach(function(product){
//                 var t = $(`#${product["id"]}`);
//                 t.show();
//                 if (product[`${productVar}`] >= checkCondition && product[`${productVar}`] < checkLimit){
//                     // console.log("checked" + product["id"])
//                     // t.addClass('collapse')
//                     // t.modal();
//                 }
//             })
//         }
//     })
// }

$(function() {

    // checkBox('available','stock',1,Number.MAX_SAFE_INTEGER);
    // checkBox('unavailable','stock',0,1);
    // checkBox('0to25','price',0,25)
    // checkBox('25to50','price',25,50)
    // checkBox('50to100','price',50,100)
    // checkBox('1thump','rating',2,3)
    // checkBox('2thump','rating',2,3)
    var productUnavailable = []
    var productAvailable = []
    var productShown = []
    var productPriceHidden = []
    var productRatingHidden = []
    var temp = {}

    $("#available").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                if ($("#unavailable").prop('checked')){
                    var t = $(`#${product["id"]}`);
                    t.show();
                    
                }else{    
                    var t = $(`#${product["id"]}`);
                    
                    // if (!(t.text() in productShown)){
                    //     t.hide();
                    // }
                    if (product["stock"] === 0){
                        // console.log(productShown)
                        // console.log("checked" + product["id"])
                        // t.addClass('collapse')
                        // t.modal();
                        t.hide();
                        productUnavailable.push(product)
                        // productShown[product["id"]] = "shown"
                        // temp[product["id"]] = ""
                    }else{
                        productShown.push(product["id"])
                    }
                }
            })
            // console.log(productShown)
        }else{
            // console.log(available)
            // products.forEach(function(product){
            //     var t = $(`#${product["id"]}`);
            //     t.hide();
            // })
            productUnavailable.forEach(function (product){
                var t = $(`#${product["id"]}`);
                t.show()
            })
                // productUnavailable = []
            // products.forEach(function(product){
            //     var t = $(`#${product["id"]}`);
            //     if (product["stock"] === 0){
            //         // console.log("checked" + product["id"])
            //         // t.addClass(' collapse')
            //         // t.modal();
            //         // Object.keys(temp).forEach(function(key){
            //         //     console.log(key)
            //         //     delete productShown[key];
            //         // });
            //         // console.log([productShown])
            //         t.hide();
                // }
            // })
        }
    })

    $("#unavailable").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                if ($("#available").prop('checked')){
                    var t = $(`#${product["id"]}`);
                    t.show();
                }else{
                    var t = $(`#${product["id"]}`);
                    if (product["stock"] !== 0){
                        // console.log(product["id"])
                        // if (productShown.includes(product["id"])){
                        //     // console.log("found: "+product["id"])
                        // }else{
                        t.hide();
                        // }
                        productAvailable.push(product);
                    }else{
                        t.show();
                    }
                }
                // console.log(productShown)

            })
        }else{
            productAvailable.forEach(function (product){
                var t = $(`#${product["id"]}`);
                t.show()
            })
        }
    })

    $("#0to25").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                if (!(product["price"] >= 0 && product["price"] <= 25)){
                    // console.log("checked" + product["id"])
                    var t = $(`#${product["id"]}`);
                    t.hide();
                    productPriceHidden.push(product);
                }
            })
        }else{
            productPriceHidden.forEach(function (product){
                var t = $(`#${product["id"]}`);
                t.show()
            })
        }
    })

    $("#25to50").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                if (!(product["price"] >= 25 && product["price"] <= 50)){
                    // console.log("checked" + product["id"])
                    var t = $(`#${product["id"]}`);
                    t.addClass('collapse')
                    // t.modal();
                    t.hide();
                }
            })
        }else{
            products.forEach(function(product){
                if (!(product["price"] >= 25 && product["price"] <= 50)){
                    // console.log("checked" + product["id"])
                    var t = $(`#${product["id"]}`);
                    // t.addClass('collapse')
                    // t.modal();
                    t.show();
                }
            })
        }
    })

    $("#50to100").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                if (!(product["price"] >= 50 && product["price"] <= 100)){
                    // console.log("checked" + product["id"])
                    var t = $(`#${product["id"]}`);
                    t.addClass('collapse')
                    // t.modal();
                    t.hide();
                }
            })
        }else{
            products.forEach(function(product){
                if (!(product["price"] >= 50 && product["price"] <= 100)){
                    // console.log("checked" + product["id"])
                    var t = $(`#${product["id"]}`);
                    // t.addClass('collapse')
                    // t.modal();
                    t.show();
                }
            })
        }
    })

    $("#1thump").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                var t = $(`#${product["id"]}`);

                if (product["rating"] < 1){
                    t.hide();
                    productRatingHidden.push(product);
                }
            })
        }else{
            productRatingHidden.forEach(function (product){
                var t = $(`#${product["id"]}`);
                t.show();
            })
        }
    })

    $("#2thump").click(function() {
        if ($(this).prop('checked')){
            products.forEach(function(product){
                var t = $(`#${product["id"]}`);

                if (product["rating"] < 2){
                    t.hide();
                    productRatingHidden.push(product);
                }
            })
        }else{
            productRatingHidden.forEach(function (product){
                var t = $(`#${product["id"]}`);
                t.show();
            })
        }
    })

    // save the firebase database to a variable named database
    var database = firebase.database();
    // use database to access "departments/books"
    database.ref("departments/books").once("value").then(function(snapshot) {
        // save the snapshot value to a local variable named data
        var data = snapshot.val();
        // log the data
        console.log(data);
        // use JQuery to create a div "row" element
        var row = $('<div class="row"></div>');
        // get all product names by using Object.keys, and iterate over with forEach
        var count = 0;
        Object.keys(data["products"]).forEach(function(key) {
            // save book to a local variable named book
            var book = data["products"][key];
            // row logic
            // log the book
            // console.log([book]);
            // push the book to products
            products.push(book);
            // use JQuery to create an h1 element with the text of the book's name
            // the h1 element should have id="book["id"]"
            var bookHTML = $('<h4 class=\'card-title\'"></h4>').text(book["name"]);
            bookHTML.append($('<h5 class=\'card-text\'></h5>').text("Category: "+book["genre"]));
            bookHTML.append($('<h5 class=\'card-text\'></h5>').text("Availability: "+ (book["stock"] === 0 ? "Not Available" : "Available")));
            bookHTML.append($('<h5 class=\'card-text\'></h5>').text("Price: $"+book["price"]));
            bookHTML.append($('<h5 class=\'card-text\'></h5>').text("Rating: "+book["rating"]));
            // use JQuery to create a div "col" element
            var col = $('<div class="col-sm-4"></div>');
            var card = $('<div class="card mt-3 collapse" id="'+book["id"]+'"></div>');
            var cardBody = $('<div class="card-body"></div>');
            cardBody.append(bookHTML);
            card.append(cardBody);
            col.append(card);
            // append the book to the "col" element
            // append the "col" element to the "row" element
            row.append(col);
            $("#content-body").append(row);
        // end forEach
        });
        // use JQuery to append the "row" element to the "container" element
    });
    //end database



});
